/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

/**
 *
 * @author Borthwick
 */
public class register {
    private static boolean returnMessage = false;
    public Socket client;
    DataOutputStream out;
    
    public register(Socket _client) throws IOException
    {
        client = _client;
        out = new DataOutputStream(client.getOutputStream());
    }
     // This sends data to the server to see if login is valid 
    public void login(String username, String password) throws IOException
    {
        System.out.println("Connected to " + client.getRemoteSocketAddress());
        OutputStream outToServer = client.getOutputStream();
        DataOutputStream out = new DataOutputStream(outToServer);
 
        out.writeUTF(username);

        out.writeUTF(password);
    }
        // This collects the data from the java page and sends it to the 
        // server where it will create a new register
    public void register(String username, String password, String fullName, String location, String genre, String Dob1, String Dob2, String Dob3) throws IOException
    {
        System.out.println("Connected to " + client.getRemoteSocketAddress());
        OutputStream outToServer = client.getOutputStream();
        DataOutputStream out = new DataOutputStream(outToServer);
        
        out.writeUTF(username);

        out.writeUTF(password);
        
        out.writeUTF(fullName);
        
        out.writeUTF(location);
        
        out.writeUTF(genre);
        
        out.writeUTF(Dob1);
        
        out.writeUTF(Dob2);
        
        out.writeUTF(Dob3);
        
        checklogin(client);
    }
    
    public void checklogin (Socket client) throws IOException{
        
        DataInputStream inFromServer = new DataInputStream(client.getInputStream());
        
        String data = inFromServer.readUTF();
        System.out.println("Server said: " + data);
    }
    
    public void sendToClient(String message) throws IOException
    {
        out.writeUTF(message);
    }
}
