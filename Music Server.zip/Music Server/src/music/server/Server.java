/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music.server;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author Lord Borthwick
 */
public class Server {
        ServerSocket ss;
        ArrayList<ServerConnection> connections = new ArrayList();
        boolean shouldRun = true;
        
        public Server(){
            try{
                ss = new ServerSocket(3333);
                while(shouldRun){
                    
                    Socket s = ss.accept();
                    ServerConnection sc = new ServerConnection(s, this);
                    connections.add(sc);
                }                 
            }
            catch (Exception e){
                e.printStackTrace(); 
        }
    }
}
