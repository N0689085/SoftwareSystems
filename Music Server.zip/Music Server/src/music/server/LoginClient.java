package music.server;

import java.net.Socket;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.io.PrintStream;
/**
 *
 * @author Lord Borthwick
 */
public class LoginClient {
    
    public static void main(String args[]) throws UnknownHostException, IOException
    {
        String username;
        String password;
        
        Scanner sc = new Scanner(System.in);
        Socket s = new Socket("127.0.0.1",1122);
        Scanner sc1= new Scanner(s.getInputStream());
        
        System.out.println("Enter a username");
        username= sc.next();
        PrintStream UsernameSend = new PrintStream(s.getOutputStream());
        
        System.out.println("Enter a password");
        password= sc.next();
        PrintStream PasswordSend= new PrintStream(s.getOutputStream());
        
        //p.println(fill);
        //temp=sc1.nextInt();
        //System.out.println(temp);
        
    }
    
}
