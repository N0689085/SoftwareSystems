package music.server;

import java.net.Socket;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.io.PrintStream;
/**
 *
 * @author Lord Borthwick
 */
public class LoginClient {
    private static boolean returnMessage = false;
    
    public static void main(String args[]) throws UnknownHostException, IOException
    {
        String username;
        String password;
        
        Scanner sc = new Scanner(System.in);
        Socket s = new Socket("127.0.0.1",9090);
        Scanner sc1= new Scanner(s.getInputStream());
        
        System.out.println("Enter a username");
        username= sc.next();
        PrintStream UsernameSend = new PrintStream(s.getOutputStream());
        
        System.out.println("Enter a password");
        password= sc.next();
        PrintStream PasswordSend= new PrintStream(s.getOutputStream());
        
        PasswordSend.println(password);
        returnMessage=sc1.nextBoolean();
        if (returnMessage) {
            System.out.println("Correct");
        }
        else {
            System.out.println("False");
        }
        
    }
    
}
