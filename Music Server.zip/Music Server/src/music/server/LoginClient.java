package music.server;

import java.net.Socket;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.io.*;
/**
 *
 * @author Lord Borthwick
 */
public class LoginClient {
    private static boolean returnMessage = false;
    
    public static void main(String args[]) throws UnknownHostException, IOException
    {
      
        Socket client = new Socket("localhost", 9090);
        System.out.println("Connected to " + client.getRemoteSocketAddress());
        OutputStream outToServer = client.getOutputStream();
        DataOutputStream out = new DataOutputStream(outToServer);
        
        System.out.println("Enter username: \n");
        Scanner sc = new Scanner(System.in);
        String username = sc.nextLine();
        out.writeUTF(username);
        
        System.out.println("Enter password: \n");
        Scanner scc = new Scanner(System.in);
        String password = scc.nextLine();
        out.writeUTF(password);
    }
    
}
