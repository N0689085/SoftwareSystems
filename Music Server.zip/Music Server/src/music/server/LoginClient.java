package music.server;

import java.net.Socket;
import java.io.IOException;
import java.io.*;
/**
 *
 * @author Lord Borthwick
 */
public class LoginClient {
    private static boolean returnMessage = false;
    public Socket client;
    DataOutputStream out;
    
    public LoginClient(Socket _client) throws IOException
    {
        client = _client;
        out = new DataOutputStream(client.getOutputStream());
    }
     
    public void login(String username, String password) throws IOException
    {
        System.out.println("Connected to " + client.getRemoteSocketAddress());
        OutputStream outToServer = client.getOutputStream();
        DataOutputStream out = new DataOutputStream(outToServer);
        
       // System.out.println("Enter username: \n");
       // Scanner sc = new Scanner(System.in);
       // String username = sc.nextSysLine();
        out.writeUTF(username);
        
      //  System.out.println("Enter password: \n");
      //  Scanner scc = new Scanner(System.in);
       // String password = scc.nextLine();
        out.writeUTF(password);
        
        checklogin(client);
    }
    
    public void checklogin (Socket client) throws IOException{
        
        DataInputStream inFromServer = new DataInputStream(client.getInputStream());
        
        String data = inFromServer.readUTF();
        System.out.println("Server said: " + data);
    }
    
    public void sendToClient(String message) throws IOException
    {
        out.writeUTF(message);
    }
}
