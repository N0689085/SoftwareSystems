package music.server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Scanner;
import java.net.Socket;
import java.util.HashMap;

/**
 *
 * @author Lord Borthwick
 */


public class MusicServer {
    private static String FileLocation = File.separator + "Users" + File.separator + "Nathan B" + File.separator + "Desktop" + File.separator + "Music Server" + File.separator + "src" + File.separator + "Login.txt";
    //private static String FileLocation = File.separator + "Users" + File.separator +"Lord Borthwick" + File.separator + "Documents" + File.separator + "NetBeansProjects" + File.separator +"Music Server" + File.separator + "src" + File.separator + "Login.txt";
    private static Scanner ii;
    String username = "";
    String password = "";

    public static void main(String args[]) throws IOException{
        
        String username = "";
        String password = "";
        
        while (true) {
            ServerSocket serverSocket = new ServerSocket(9090);
            Socket server = serverSocket.accept();
            
            DataInputStream in = new DataInputStream(server.getInputStream());
            username = (in.readUTF());
            password = (in.readUTF());
            
            checkLogin(username, password); 
            
            serverSocket.close();
        }
    }
    
    //-----------------------------------------------------------------------
    
    public static void testInput(String user, String Pass) {
        if (user.equals("Nathan") || Pass.equals("Pass")) {
            System.out.println("Correct User");
        } else {
            System.out.println("Incorrect User");
        }
    }

    
//---------------------------------------------------------------------------    
    

    public static void checkLogin (String username, String password) {

        boolean check = false;
        boolean returnMessage = false;
        String checkUser = "";
        String checkPassword = "";
        String test = "";
        HashMap<String, String> users = new HashMap();
        
        try {
            Scanner ii = new Scanner(new File((FileLocation)));
            while (ii.hasNext()) {
                String line = ii.nextLine();
                String[] parts = line.split(":");
                users.put(parts[0], parts[1]);
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Error file not found");
        }
        
        try{
            if (users.get(username).equals(password)){
                System.out.println("Correct");
            }
        } 
        catch (Exception e){
            System.out.println("Yeet");
        }
    }
}
