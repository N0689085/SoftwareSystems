package music.server;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.util.Scanner;
import java.net.Socket;

/**
 *
 * @author Lord Borthwick
 */
public class MusicServer {

    public static void main(String args[]) throws IOException{
        
        String username;
        String password;
        String checkfile = "login.txt";
        
        ServerSocket s1=new ServerSocket(1122);
        Socket ss=s1.accept();
        
        Scanner sc=new Scanner(ss.getInputStream());
        username=sc.next();
        password=sc.next();
        
        //-------------(this below is wrong and needs fixing)
        
        //checkLogin(username,password,checkfile);
        
        //PrintStream p=new PrintStream(ss.getOutputStream());
        //p.println(temp);
    }
//---------------------------------------------------------------------------    
    private static Scanner ii;
    

    public static void checkLogin (String username, String password){
        
        boolean check = false;
        String checkUser ="";
        String checkPassword ="";
        
        try
        {
           //-------------(need to connect this to the file R.I.P)
           ii = new Scanner(new File(login));
           ii.useDelimiter("(:\n");
           
           while(ii.hasNext() && !check){
               checkUser = ii.next();
               checkPassword = ii.next();
               if(checkUser.trim().equals(username) && checkPassword.trim().equals(password)){
                   check = true;
               }
           }
           ii.close();
           System.out.println("Login Successful");
           
        }
        catch(Exception e){
            System.out.println("Credentials Incorrect");
        }
    }
}
