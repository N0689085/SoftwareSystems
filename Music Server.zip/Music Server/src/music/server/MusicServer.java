package music.server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Scanner;
import java.net.Socket;
import java.util.HashMap;

/**
 *
 * @author Lord Borthwick
 */


public class MusicServer {
    //private static String FileLocation = File.separator + "Users" + File.separator + "Nathan B" + File.separator + "Desktop" + File.separator + "Music Server" + File.separator + "src" + File.separator + "Login.txt";
    private static final String FileLocation = File.separator + "Users" + File.separator +"Lord Borthwick" + File.separator + "Documents" + File.separator + "NetBeansProjects" + File.separator +"Music Server" + File.separator + "src" + File.separator + "Login.txt";
    private static Scanner ii;
    String username = "";
    String password = "";
    private static LoginClient login;
    //private static RegisterClient register;
    private final Server server;
    
    public MusicServer(LoginClient _login, Server _server //*RegisterClient _register*//
            )
    {
        login = _login;
        server = _server;
        //register = _register;
    }
    
    public static void main(String args[]) throws IOException{
        
        String username = "";
        String password = "";
        ServerSocket serverSocket = new ServerSocket(9090);
        while (true) {
            
            Socket server = serverSocket.accept();
            
            DataInputStream in = new DataInputStream(server.getInputStream());
            username = (in.readUTF());
            password = (in.readUTF());
            
            checkLogin(username, password); 
            
            //serverSocket.close();
        }
    }
    
    //-----------------------------------------------------------------------
    
    public static void testInput(String user, String Pass) {
        if (user.equals("Nathan") || Pass.equals("Pass")) {
            System.out.println("Correct User");
        } else {
            System.out.println("Incorrect User");
        }
    }

//---------------------------------------------------------------------------    
    

    public static void checkLogin (String username, String password) {

        String check = "Logged In...";
        //boolean returnMessage = ;

        HashMap<String, String> users = new HashMap();
        
        try {
            Scanner ii = new Scanner(new File((FileLocation)));
            while (ii.hasNext()) {
                String line = ii.nextLine();
                String[] parts = line.split(":");
                String put = users.put(parts[0], parts[1]);
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Error file not found");
        }
        
        try{
            if (users.get(username).equals(password)){
                System.out.println("Correct");             
                login.sendToClient("You have logged in");   
            }
        } 
        catch (Exception e){
            System.out.println("Credentials Incorrect");
        }
    }
    
    public static void confirmRegister (String username, String Password, String fullName, String Location, String Genre, String Dob1, String Dob2, String Dob3) throws IOException 
    {
        
        String password = "";
        ServerSocket serverSocket = new ServerSocket(9090);
        while (true) {
            Socket server = serverSocket.accept();
        
            DataInputStream in = new DataInputStream(server.getInputStream());
            username = (in.readUTF());
            password = (in.readUTF());
            
        }
     
     
    
     
 }   
    
    
    
    
    
    
    
    
}
