package music.server;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.util.Scanner;
import java.net.Socket;

/**
 *
 * @author Lord Borthwick
 */


public class MusicServer {
    private static String checkfile = "login.txt";
    private static boolean returnMessage = false;

    public static void main(String args[]) throws IOException{
        
        String username;
        String password;
        String checkfile = "login.txt";
        
        ServerSocket s1=new ServerSocket(9090);
        Socket ss=s1.accept();
        
        Scanner sc=new Scanner(ss.getInputStream());
        username=sc.next();
        password=sc.next();
        
        //-------------(this below is wrong and needs fixing)
        
        MusicServer.checkLogin(username,password,checkfile);
        
        PrintStream p=new PrintStream(ss.getOutputStream());
        p.println(returnMessage);
        
    }   
    
    
//---------------------------------------------------------------------------    
    private static Scanner ii;
    

    public static void checkLogin (String username, String password, String checkfile){
        
        //boolean check = false;
        boolean check = false;
        boolean returnMessage = false;
        String checkUser ="";
        String checkPassword ="";
        
        try
        {
            
           ii = new Scanner(new File(checkfile));
           ii.useDelimiter("(:\n");
           
           while(ii.hasNext() && !check){
               checkUser = ii.next();
               checkPassword = ii.next();
               if(checkUser.trim().equals(username) && checkPassword.trim().equals(password)){
                   check = true;
               }
           }
           ii.close();
           System.out.println("Login Successful");
           returnMessage = true;
           
           
        }
        catch(Exception e){
            System.out.println("Credentials Incorrect");
        }
    }
}
