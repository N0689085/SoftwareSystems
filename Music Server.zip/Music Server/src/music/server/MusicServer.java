package music.server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Scanner;
import java.net.Socket;

/**
 *
 * @author Lord Borthwick
 */


public class MusicServer {
    private static String FileLocation = File.separator + "Users" + File.separator +"Lord Borthwick" + File.separator + "Documents" + File.separator + "NetBeansProjects" + File.separator +"Music Server" + File.separator + "src" + File.separator + "Login.txt";
    private static Scanner ii;
    String username = "";
    String password = "";

    public static void main(String args[]) throws IOException{
        
        String username = "";
        String password = "";
        
        while (true) {
            ServerSocket serverSocket = new ServerSocket(9090);
            Socket server = serverSocket.accept();
            
            DataInputStream in = new DataInputStream(server.getInputStream());
            username = (in.readUTF());
            password = (in.readUTF());
            
            checkLogin(username, password); 
            
            serverSocket.close();
        }
    }
    
    //-----------------------------------------------------------------------
    
    public static void testInput(String user, String Pass) {
        if (user.equals("Nathan") || Pass.equals("Pass")) {
            System.out.println("Correct User");
        } else {
            System.out.println("Incorrect User");
        }
    }

    
//---------------------------------------------------------------------------    
    

    public static void checkLogin (String username, String password) {

        boolean check = false;
        boolean returnMessage = false;
        String checkUser = "";
        String checkPassword = "";
        
        try
        {          
           ii = new Scanner(new File(FileLocation));
           Scanner LoginCheck = new Scanner(FileLocation);
           Scanner file = new Scanner(new File(FileLocation));

           ii.useDelimiter(":");
           
           while(ii.hasNext() && !check){
               
               System.out.println("hi");
               
               checkUser = ii.next();
               System.out.println(checkUser);
               //checkPassword = ii.next();
               
               if(checkUser.trim().equals(username) && checkPassword.trim().equals(password)){
                   check = true;
                   ii.close();
                   System.out.println("Login Successful");
                   returnMessage = true;
                   System.out.println(username + "worked");
                   System.out.println(password + "worked");
               }
           }         
        }
        catch(FileNotFoundException e){
            System.out.println(checkUser);
            System.out.println(checkPassword);
            System.out.println("Credentials Incorrect");
            System.out.println(username);
            System.out.println(password);
        }
    }
}
